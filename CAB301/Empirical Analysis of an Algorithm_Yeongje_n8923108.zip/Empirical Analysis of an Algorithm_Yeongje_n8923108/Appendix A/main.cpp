#include <iostream>
#include <cstdlib>
#include <cmath>
#include <time.h>

using namespace std;

int main()
{
    int num, n, temp;
    cin>>num;
    int index_size = num -1 ;
    int Anum[num];
    clock_t start, finish;
    int NBO=0;
    double k = fabs(num/2.0);

    for (int i=0;i<num;i++){
        Anum[i] = i;
    }
    for(int i=0;i<num;i++){
        n = rand()%(index_size+1);
        temp = Anum[n];
        Anum[n] = Anum[index_size];
        Anum[index_size] = temp;
    }
    cout<<"[";
    for(int l =0;l<num-1;l++)
    {
        cout<< Anum[l] << " , " ;
    }
    cout << Anum[num-1] << "]" << endl;

    start = clock();
    for(int i =0;i<num;i++){
        int numsmaller =0;
        int numequal =0;
        for(int j=0;j<num;j++){
                NBO++;
            if(Anum[j]<Anum[i])
            {
                numsmaller = numsmaller + 1;
            }
            else{
                if(Anum[i]==Anum[j]){
                    numequal = numequal + 1;
                }
            }
        }
        if((double)numsmaller<k && k<=(double)(numequal+numsmaller)){
            finish = clock();
            double timer = ((double)(finish-start));
            cout << "The median number : "<< Anum[i] << endl;
            cout << "Execution time : " << timer << endl;
            cout << "The number of basic of operation : " << NBO;
        }
    }
    return 0;
}

