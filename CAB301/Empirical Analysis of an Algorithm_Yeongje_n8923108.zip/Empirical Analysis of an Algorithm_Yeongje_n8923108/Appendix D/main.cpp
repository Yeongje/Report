#include <iomanip>
#include <fstream>
#include <iostream>
#include <cstdlib>
#include <cmath>
#include <time.h>

using namespace std;

int main()
{
    ofstream fout;
    fout.open("info.txt");  // write the results in infor.txt file
    int num, n, temp;
    int setSize = 10001;
    for(int i=1; i<11; i++)
    {
        srand(i); // By changing number between 1 and 10 for different random array.
        fout<< "                 " << endl;
        for(num = 100; num<setSize; num=num+100)  // From 100 to 10000 array by each 100 times
        {

            int index_size = num -1 ;
            int Anum[num];

            int NBO=0; // number of basic operation;
            double k = fabs(num/2.0); //

            for (int i=0; i<num; i++)
            {
                Anum[i] = i;
            }
            for(int i=0; i<num; i++)
            {
                n = rand()%(index_size+1);

                temp = Anum[n];
                Anum[n] = Anum[index_size];
                Anum[index_size] = temp;
            }

            for(int i =0; i<num; i++)
            {
                int numsmaller =0;
                int numequal =0;
                for(int j=0; j<num; j++)
                {
                    NBO++;  // the number of basic function
                    if(Anum[j]<Anum[i]){
                        numsmaller = numsmaller + 1;
                    }
                    else
                    {
                        if(Anum[i]==Anum[j])
                        {
                            numequal = numequal + 1;
                        }
                    }
                }
                if((double)numsmaller<k && k<=(double)(numequal+numsmaller))
                {
                    fout<< NBO<<endl;  // The number of basic operation
                }
            }
        }

    }

    fout.close();
    return 0;
}


