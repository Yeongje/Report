#include <iostream>
#include <cmath>

using namespace std;

int main()
{
    int Anum[] = {9,5,4,1,7,16,14,6,11,0,18};
    int siz = (sizeof(Anum)/sizeof(int));
    int NBO =0;
    double k = fabs(siz/2.0);

    cout << "The array contains " << siz << " numbers" << endl;
    for(int i =0;i<siz;i++){
        int numsmaller =0;
        int numequal =0;
        for(int j=0;j<siz;j++){
                NBO++;
            if(Anum[j]<Anum[i])
            {
                numsmaller = numsmaller + 1;
            }
            else{
                if(Anum[i]==Anum[j]){
                    numequal = numequal + 1;
                }
            }
        }
        if((double)numsmaller<k && k<=(double)(numequal+numsmaller)){
            cout << "The median number : "<< Anum[i] << endl;
            cout << "The number of basic operations : "<< NBO<< endl;
        }
    }
    return 0;
}
