#include <iostream>
#include <limits>
#include <cstdlib>
#include <cmath>
#include <time.h>
#include <math.h>
#include <fstream>

using namespace std;

int main()
{
    ofstream fout;
    fout.open("result.txt");
    int num,n;

    for(int i=1; i<11; i++)
    {
        srand(i);
        fout<< "             "<<endl;
        for(num = 100; num<10001; num=num+100)
        {
            int Anum[num];
            int NBO = 0; // Basic operation
            int dmin = numeric_limits<int>::max();
            for(int i =0; i<num; i++)
            {
                n = (rand()%(dmin));
                Anum[i] = abs(n);
            }

            // First algorithm
            for(int i = 0; i<num - 1; i++)
            {
                for(int j = 0; j<num-1 ; j++ )
                {
                    NBO++;
                    if( i != j && abs(Anum[i]-Anum[j]) <dmin)
                    {
                        dmin = abs(Anum[i]-Anum[j]);
                    }
                }
            }

            fout<<NBO<<endl;
        }
    }
    fout.close();
    return 0;
}
