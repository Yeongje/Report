#include <iostream>
#include <limits>
#include <cstdlib>
#include <cmath>
#include <time.h>
#include <math.h>
#include <fstream>

using namespace std;

int main()
{
    ofstream fout;
    fout.open("result.txt");
    int num,n;
    for(int i=1; i<11; i++)
    {
        srand(i);
        fout<< "             "<<endl;

        for(num = 100; num<10001; num=num+100)
        {
            int Anum[num];
            clock_t start, finish;
            int dmin = numeric_limits<int>::max();
            for(int i =0; i<num; i++)
            {
                n = (rand()%(dmin));
                Anum[i] = abs(n);
            }


            start = clock();
            for(int i = 0; i<num - 1; i++)
            {
                for(int j = 0; j<num-1 ; j++ )
                {
                    if( i != j && abs(Anum[i]-Anum[j]) <dmin)
                    {
                        dmin = abs(Anum[i]-Anum[j]);
                    }
                }
                finish = clock();
            }
            double timer = ((double)(finish - start));

            fout<<timer<<endl;
        }
    }
    fout.close();
    return 0;
}
