#include <iostream>
#include <limits>
#include <cstdlib>
#include <cmath>
#include <time.h>
#include <math.h>
#include <fstream>

using namespace std;

int main()
{
    ofstream fout;
    fout.open("result.txt");
    int num,n;

    for(num = 100; num<10001; num=num+100)
    {
        int Anum[num];
        clock_t start, finish;
        int dmin = numeric_limits<int>::max();
        for(int i =0; i<num; i++)
        {
            n = (rand()%(dmin));
            Anum[i] = abs(n);
        }

        // First algorithm
        start = clock();

        for(int i = 0; i<num - 2; i++)
        {
            for(int j = i+1; j<num-1 ; j++ )
            {
                int dis = abs(Anum[i]-Anum[j]);
                if( dis <dmin)
                {
                    dmin = abs(dis) ;
                }
            }
            finish = clock();
        }
        double timer = ((double)(finish - start));

        fout<<timer<<endl;
    }
    fout.close();
    return 0;
}
