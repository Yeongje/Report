#include <iostream>
#include <limits>
#include <cstdlib>
#include <cmath>
#include <time.h>
#include <math.h>

using namespace std;

int main()
{
    int num,n;
    int dmin = numeric_limits<int>::max();
    cin>>num;
    int Anum[num];
    int NBO = 0; // Basic operation
    clock_t start, finish; // timer


    for(int i =0;i<num;i++){
        n = (rand()%(dmin));
        Anum[i] = abs(n);
    }

       cout <<"[";
    for(int l =0;l<num-1;l++){
        cout << Anum[l] << " , ";
    }
    cout << Anum[num-1] << "]" << endl;

    start = clock();
    /*
    // First algorithm
    for(int i = 0; i<num - 1; i++){
        for(int j = 0; j<num-1 ; j++ ){
                NBO++;
            if( i != j && abs(Anum[i]-Anum[j]) <dmin){
                dmin = abs(Anum[i]-Anum[j]);
            }
        }
    }
*/
    // Second algorithm
     for(int i = 0; i<num - 2; i++){
        for(int j = i+1; j<num-1 ; j++ ){
                NBO++;
                int dis = abs(Anum[i]-Anum[j]);
            if( dis <dmin){
                dmin = abs(dis) ;
            }
        }
    }


    finish = clock();
    double timer = ((double)(finish - start));
    cout << "The number of basic of operation : " << NBO << endl;
    cout << "Execution time : " << timer << endl;
    cout << "The minimum distance is "<< dmin <<endl;

    return 0;
}
