#include <iostream>
#include <limits>
#include <cstdlib>
#include <cmath>
#include <time.h>
#include <math.h>

using namespace std;

int main()
{

    int dmin = numeric_limits<int>::max();
    int Anum[] = {0,9,4,3,5,2,6,7,1,8};
    int num =(sizeof(Anum)/sizeof(int));
    int NBO = 0;
    clock_t start, finish;

    cout <<"[";
    for(int l =0; l<num-1; l++)
    {
        cout << Anum[l] << " , ";
    }
    cout << Anum[num-1] << "]" << endl;

    start = clock();
    for(int i = 0; i<num - 1; i++)
    {
        for(int j = 0; j<num-1 ; j++ )
        {
            NBO++;
            if( i != j && abs(Anum[i]-Anum[j]) <dmin)
            {
                dmin = abs(Anum[i]-Anum[j]);
            }
        }
        finish = clock();
    }
    double timer = ((double)(finish - start));
    cout << "The number of basic of operation : " << NBO << endl;
    cout << "The execution time : " << timer << "(millisecond)" << endl;
    cout << "The set contains "<< num << " items" << endl;
    cout << "The minimum distance is "<< dmin <<endl;

    return 0;
}
